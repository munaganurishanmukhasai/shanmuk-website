# SHANMUK Personal Website

Open `index.html` in a browser to preview the website.

Before publishing, replace:
- Instagram URLs (`https://instagram.com/`) with your actual Instagram profile
- `your@email.com` with your email
- GitHub/LinkedIn `#` links with your profiles
- The placeholder avatar `S` with your own photo if desired.

The site is responsive and uses only HTML/CSS/JavaScript, so no installation is required.
